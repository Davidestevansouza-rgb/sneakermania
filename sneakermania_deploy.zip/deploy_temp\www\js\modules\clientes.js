﻿/* ============================================================
   CLIENTES â€” SneakerMania
   ============================================================ */
import { state, persist } from '../state.js';
import { showToast, logActivity, clienteById, clienteNombre, openModalEl, closeModal, lockBtn } from '../ui.js';
import { escHtml, escAttr } from '../sanitize.js';
import * as db from '../db.js';

export function renderClientes(filter = '') {
  document.getElementById('clientes-sub').textContent = state.clientes.length + ' clientes registrados';
  const esAdmin = state.session && state.session.role === 'Administrador';
  const f = filter.toLowerCase();
  const rows = state.clientes.filter(c => !f || c.nombre.toLowerCase().includes(f) || (c.telefono || '').includes(f));
  const html = '<thead><tr><th>Nombre</th><th>TelÃ©fono</th><th>WhatsApp</th><th>DirecciÃ³n</th><th>Servicios</th><th></th></tr></thead><tbody>' +
    rows.map(c => {
      const historial = state.ordenes.filter(o => o.clienteId === c.id).length;
      return '<tr><td data-label=""><strong>' + escHtml(c.nombre) + '</strong>' + (c.observaciones ? '<div class="hint">' + escHtml(c.observaciones) + '</div>' : '') + '</td>' +
        '<td data-label="TelÃ©fono">' + escHtml(c.telefono) + '</td><td data-label="WhatsApp">' + escHtml(c.whatsapp) + '</td><td data-label="DirecciÃ³n">' + escHtml(c.direccion) + '</td>' +
        '<td data-label="Servicios">' + historial + ' Ã³rdenes</td>' +
        '<td data-label="" style="white-space:nowrap;"><button class="btn btn-ghost btn-sm" onclick="openClienteModal(\'' + escAttr(c.id) + '\')">Editar</button> ' +
        '<button class="btn btn-ghost btn-sm" onclick="viewClienteHistorial(\'' + escAttr(c.id) + '\')">Historial</button>' +
        (esAdmin ? ' <button class="btn btn-ghost btn-sm" style="color:var(--red);" onclick="deleteCliente(\'' + escAttr(c.id) + '\')">Eliminar</button>' : '') +
        '</td></tr>';
    }).join('') + '</tbody>';
  document.getElementById('clientes-table').innerHTML = html || '<tr><td>Sin resultados</td></tr>';
}

export function openClienteModal(id) {
  document.getElementById('cliente-id').value = id || '';
  document.getElementById('cliente-modal-title').textContent = id ? 'Editar cliente' : 'Nuevo cliente';
  const c = id ? clienteById(id) : { nombre: '', telefono: '', whatsapp: '', direccion: '', observaciones: '' };
  document.getElementById('cliente-nombre').value = c.nombre;
  document.getElementById('cliente-telefono').value = c.telefono;
  document.getElementById('cliente-whatsapp').value = c.whatsapp;
  document.getElementById('cliente-direccion').value = c.direccion;
  document.getElementById('cliente-observaciones').value = c.observaciones;
  openModalEl('modal-cliente');
}

export async function saveCliente(btn) {
  const id = document.getElementById('cliente-id').value;
  const data = {
    nombre: document.getElementById('cliente-nombre').value.trim(),
    telefono: document.getElementById('cliente-telefono').value.trim(),
    whatsapp: document.getElementById('cliente-whatsapp').value.trim(),
    direccion: document.getElementById('cliente-direccion').value.trim(),
    observaciones: document.getElementById('cliente-observaciones').value.trim()
  };
  if (!data.nombre) { showToast('Falta completar: Nombre'); document.getElementById('cliente-nombre').focus(); return; }
  if (!data.whatsapp) { showToast('Falta completar: NÃºmero de WhatsApp'); document.getElementById('cliente-whatsapp').focus(); return; }
  const restore = lockBtn(btn);   // evita doble guardado
  try {
    let registro;
    if (id) {
      registro = clienteById(id);
      Object.assign(registro, data);
      logActivity('EditÃ³ cliente ' + data.nombre);
    } else {
      data.id = crypto.randomUUID();   // UUID real (corrige el uso de Date.now())
      state.clientes.push(data);
      registro = data;
      logActivity('RegistrÃ³ nuevo cliente ' + data.nombre);
    }
    await persist();
    await db.saveCliente(registro);
    closeModal('modal-cliente');
    renderClientes();
    showToast('Cliente guardado');
  } catch (e) { console.error(e); showToast('Error al guardar el cliente'); }
  finally { restore(); }
}

/** Elimina un cliente (solo Administrador, con confirmaciÃ³n previa). */
/** Elimina un cliente (solo Administrador). No se borra de la base de
 *  datos: pasa a la Papelera (ConfiguraciÃ³n â†’ Papelera de clientes) hasta
 *  que se elimine definitivamente desde ahÃ­. */
export async function deleteCliente(id) {
  if (!(state.session && state.session.role === 'Administrador')) { showToast('Solo el Administrador puede eliminar clientes'); return; }
  const c = clienteById(id);
  if (!c) return;
  // No se puede eliminar un cliente con Ã³rdenes asociadas (restricciÃ³n de la base de datos).
  const nOrd = state.ordenes.filter(o => o.clienteId === id).length;
  if (nOrd > 0) {
    alert('No se puede eliminar a "' + c.nombre + '" porque tiene ' + nOrd + ' orden(es) asociada(s).\n\nPrimero elimina sus Ã³rdenes en la pestaÃ±a Ã“rdenes y vuelve a intentarlo.');
    return;
  }
  if (!confirm('Â¿Enviar a la papelera al cliente "' + c.nombre + '"?\n\nPodrÃ¡s restaurarlo desde ConfiguraciÃ³n â†’ Papelera de clientes.')) return;
  const backup = state.clientes.slice();
  c.eliminada = true;
  state.clientes = state.clientes.filter(x => x.id !== id);
  if (!Array.isArray(state.clientesEliminados)) state.clientesEliminados = [];
  state.clientesEliminados.push(c);
  renderClientes();
  const res = await db.saveCliente(c);
  if (res && res.error && !res.queued) {
    // FallÃ³ en el servidor (error permanente): restaurar el cliente en la vista.
    c.eliminada = false;
    state.clientes = backup;
    state.clientesEliminados = state.clientesEliminados.filter(x => x.id !== id);
    renderClientes();
    showToast('No se pudo enviar el cliente a la papelera: ' + (res.error.message || 'error del servidor'));
    return;
  }
  logActivity('EnviÃ³ a la papelera al cliente ' + c.nombre);
  await persist();
  showToast('Cliente enviado a la papelera');
}

/** Restaura un cliente desde la Papelera (solo Administrador). */
export async function restaurarCliente(id) {
  if (!(state.session && state.session.role === 'Administrador')) { showToast('Solo el Administrador puede restaurar clientes'); return; }
  const c = (state.clientesEliminados || []).find(x => x.id === id);
  if (!c) return;
  c.eliminada = false;
  state.clientesEliminados = state.clientesEliminados.filter(x => x.id !== id);
  state.clientes.push(c);
  renderClientes();
  await persist();
  await db.saveCliente(c);
  logActivity('RestaurÃ³ desde la papelera al cliente ' + c.nombre);
  showToast('Cliente "' + c.nombre + '" restaurado');
  if (window.renderPapeleras) window.renderPapeleras();
}

/** Elimina un cliente DEFINITIVAMENTE desde la Papelera (no se puede deshacer). */
export async function eliminarClientePermanente(id) {
  if (!(state.session && state.session.role === 'Administrador')) { showToast('Solo el Administrador puede eliminar definitivamente'); return; }
  const c = (state.clientesEliminados || []).find(x => x.id === id);
  if (!c) return;
  if (!confirm('Â¿Eliminar DEFINITIVAMENTE a "' + c.nombre + '"?\n\nEsta acciÃ³n NO se puede deshacer â€” se perderÃ¡ para siempre.')) return;
  const backup = state.clientesEliminados.slice();
  state.clientesEliminados = state.clientesEliminados.filter(x => x.id !== id);
  if (window.renderPapeleras) window.renderPapeleras();
  const res = await db.deleteCliente(id);
  if (res && res.error && !res.queued) {
    state.clientesEliminados = backup;
    if (window.renderPapeleras) window.renderPapeleras();
    showToast('No se pudo eliminar definitivamente: ' + (res.error.message || 'error del servidor'));
    return;
  }
  logActivity('EliminÃ³ definitivamente al cliente ' + c.nombre);
  showToast('Cliente eliminado definitivamente');
}

export function viewClienteHistorial(id) {
  window.switchTab('ordenes');
  document.getElementById('filtro-orden-texto').value = clienteNombre(id);
  window.renderOrdenes();
}

Object.assign(window, { renderClientes, openClienteModal, saveCliente, deleteCliente, viewClienteHistorial, restaurarCliente, eliminarClientePermanente });
