﻿/* ============================================================
   PUNTO DE ENTRADA â€” SneakerMania
   ============================================================
   Orquesta la aplicaciÃ³n: importa todos los mÃ³dulos, define la
   navegaciÃ³n entre pestaÃ±as, el menÃº mÃ³vil, la bÃºsqueda global y
   el arranque (init). La lÃ³gica de cada feature vive en su mÃ³dulo.
   ============================================================ */
import { LOGO_DATA_URI } from './logo.js';
import { supabase } from './config.js';
import { state, setState, seedData, loadCache, puedeVerTab, tabInicial } from './state.js';
import { showToast, setConnStatus, bindPrimerGestoAudio } from './ui.js';
import * as db from './db.js';
import { doLogout } from './auth.js';

// MÃ³dulos de features (cada uno se auto-registra en window).
import { renderDashboard } from './modules/dashboard.js';
import { renderClientes } from './modules/clientes.js';
import { renderOrdenes, populateClienteSelect, migrateOrdenes } from './modules/ordenes.js';
import './modules/cliente-orden.js'; // fusiÃ³n "Nuevo cliente": cliente + artÃ­culos + foto/IA + precio + pago + WhatsApp en un solo modal
import { populateIaOrderSelect } from './modules/ia.js';
import { renderGaleria, populateGaleriaSelect } from './modules/galeria.js';
import { renderProduccion } from './modules/produccion.js';
import './modules/items.js'; // artÃ­culos/precintos: se usa embebido en Detalle de orden
import { renderFinanzas } from './modules/finanzas.js';
import { initFacturasTab } from './modules/facturas.js';
import { renderInventario } from './modules/inventario.js';
import { renderReportes } from './modules/reportes.js';
import { renderAgenda } from './modules/agenda.js';
import { renderNotificaciones } from './modules/notificaciones.js';
import { renderEmpleados } from './modules/empleados.js';
import { renderConfiguracion, applyBrandLogo } from './modules/configuracion.js';
import { autoDailyBackup } from './modules/backup.js';
import './modules/whatsapp-limites.js';
import './modules/push-notifications.js';

/* ============================================================
   NAVEGACIÃ“N
   ============================================================ */
export function switchTab(tab) {
  // Control de acceso por rol: si la pestaÃ±a no estÃ¡ permitida, redirige.
  if (!puedeVerTab(tab)) {
    showToast('No tienes acceso a esta secciÃ³n');
    tab = tabInicial();
  }
  closeMobileMenu();
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab-section').forEach(s => s.classList.remove('active'));
  const sec = document.getElementById('tab-' + tab);
  if (sec) sec.classList.add('active');
  if (tab === 'dashboard') renderDashboard();
  if (tab === 'clientes') renderClientes();
  if (tab === 'ordenes') renderOrdenes();
  if (tab === 'galeria') renderGaleria();
  if (tab === 'produccion') renderProduccion();
  if (tab === 'finanzas') renderFinanzas();
  if (tab === 'facturas') initFacturasTab();
  if (tab === 'inventario') renderInventario();
  if (tab === 'agenda') renderAgenda();
  if (tab === 'reportes') renderReportes();
  if (tab === 'notificaciones') renderNotificaciones();
  if (tab === 'empleados') renderEmpleados();
  if (tab === 'configuracion' || tab === 'seguridad') renderConfiguracion();
  if (tab === 'ia') populateIaOrderSelect();
}

/* ============================================================
   MENÃš MÃ“VIL (drawer)
   ============================================================ */
export function openMobileMenu() {
  document.getElementById('app-sidebar').classList.add('open');
  document.getElementById('sidebar-backdrop').classList.add('open');
}
export function closeMobileMenu() {
  document.getElementById('app-sidebar').classList.remove('open');
  document.getElementById('sidebar-backdrop').classList.remove('open');
}

/* ============================================================
   BÃšSQUEDA GLOBAL
   ============================================================ */
export function handleGlobalSearch(q) {
  if (!q) return;
  switchTab('ordenes');
  document.getElementById('filtro-orden-texto').value = q;
  renderOrdenes();
}

/* ============================================================
   RENDER GLOBAL
   ============================================================ */
export function renderAll() {
  migrateOrdenes();
  applyBrandLogo();
  renderDashboard();
  renderClientes();
  renderOrdenes();
  renderInventario();
  renderNotificaciones();
  renderConfiguracion();
  populateIaOrderSelect();
  populateGaleriaSelect();
  populateClienteSelect();
  // Finanzas/Agenda solo si el DOM correspondiente existe.
  if (document.getElementById('fin-kpi-grid')) renderFinanzas();
  if (document.getElementById('agenda-hoy')) renderAgenda();
  // Empleados solo para administradores.
  if (state.session && state.session.role === 'Administrador') renderEmpleados();
  // Copia de seguridad automÃ¡tica diaria (una por dÃ­a, en este dispositivo).
  autoDailyBackup();
}

/* ============================================================
   ESTADO DE CONEXIÃ“N (online / offline)
   ============================================================ */
function wireConnectivity() {
  window.addEventListener('online', async () => {
    setConnStatus('online', db.pendingCount());
    const r = await db.flushQueue();
    setConnStatus('online', r.pending);
    if (r.flushed > 0) showToast('SincronizaciÃ³n completada (' + r.flushed + ' cambios).');
  });
  window.addEventListener('offline', () => {
    setConnStatus('offline', db.pendingCount());
    showToast('Sin conexiÃ³n: los cambios se guardarÃ¡n y se sincronizarÃ¡n al reconectar.');
  });
}

/* ============================================================
   CIERRE AUTOMÃTICO DE SESIÃ“N POR INACTIVIDAD (20 minutos)
   ============================================================ */
const INACTIVIDAD_MS = 8 * 60 * 60 * 1000; // 8 horas
let inactivityTimer = null;

function resetInactivityTimer() {
  // Solo cuenta si hay una sesiÃ³n activa (la app estÃ¡ visible).
  if (!(state && state.session && state.session.loggedIn)) return;
  if (inactivityTimer) clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(async () => {
    if (state && state.session && state.session.loggedIn) {
      try { await doLogout(); } catch (e) { console.error(e); }
      showToast('SesiÃ³n cerrada automÃ¡ticamente por inactividad (20 min).');
    }
  }, INACTIVIDAD_MS);
}

function wireInactivityLogout() {
  ['mousedown', 'keydown', 'touchstart', 'click', 'scroll'].forEach(ev =>
    document.addEventListener(ev, resetInactivityTimer, { passive: true }));
  resetInactivityTimer();
}

// Exponer para que auth.js reinicie el temporizador tras iniciar sesiÃ³n.
window.resetInactivityTimer = resetInactivityTimer;

/* ============================================================
   MANEJO GLOBAL DE ERRORES
   ============================================================ */
window.addEventListener('error', function (ev) {
  console.error('Error capturado:', ev.message, ev.filename, ev.lineno);
  try { showToast('OcurriÃ³ un error inesperado. Intenta de nuevo.'); } catch (e) { }
});
window.addEventListener('unhandledrejection', function (ev) {
  console.error('Promesa rechazada:', ev.reason);
  try { showToast('OcurriÃ³ un error inesperado. Intenta de nuevo.'); } catch (e) { }
});

/* ============================================================
   INIT
   ============================================================ */
(async function init() {
  // Logo (data URI incrustado) en login, sidebar y favicon.
  const setLogo = (id, prop) => { const el = document.getElementById(id); if (el) el[prop] = LOGO_DATA_URI; };
  setLogo('login-logo-img', 'src');
  setLogo('side-logo-img', 'src');
  setLogo('topbar-logo-img', 'src');
  setLogo('favicon-link', 'href');

  // Estado inicial en memoria (semilla o cachÃ© local).
  const cached = loadCache();
  setState(cached || seedData());
  if (!state.session) state.session = { loggedIn: false, role: null, user: null };

  wireConnectivity();
  wireInactivityLogout();
  // Desbloquea el audio de las alertas sonoras de notificaciones en el
  // primer click/tap (los navegadores no dejan sonar audio sin gesto
  // previo del usuario).
  bindPrimerGestoAudio();
  setConnStatus(db.online() ? 'online' : 'offline', db.pendingCount());

  // IMPORTANTE (seguridad): NO se restaura ninguna sesiÃ³n automÃ¡ticamente.
  // Con persistSession:false (ver config.js) no queda un token guardado
  // entre recargas, pero ademÃ¡s nunca se llama a onAuthenticated() aquÃ­:
  // el Ãºnico camino de acceso es doLogin() â†’ rol + usuario + contraseÃ±a +
  // botÃ³n "Iniciar sesiÃ³n". Cada recarga de pÃ¡gina exige volver a
  // autenticarse; no hay reingreso automÃ¡tico ni reutilizaciÃ³n de sesiÃ³n.
  if (supabase) {
    try { await supabase.auth.signOut(); } catch (e) { /* noop: no habÃ­a sesiÃ³n que cerrar */ }
  }
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('app-shell').style.display = 'none';
})();

// ExposiciÃ³n global para los onclick del HTML.
Object.assign(window, { switchTab, openMobileMenu, closeMobileMenu, handleGlobalSearch, renderAll });
