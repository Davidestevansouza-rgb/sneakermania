﻿/* ============================================================
   NOTIFICACIONES PUSH â€” SneakerMania (REAL, no demo)
   Web Push API: la suscripciÃ³n se guarda en Supabase
   (push_subscriptions) y la Edge Function send-push manda las
   notificaciones aunque la app estÃ© cerrada o el celular bloqueado.
   ============================================================ */
import { state } from '../state.js';
import { showToast, reproducirSonidoNotificacion } from '../ui.js';
import { supabase } from '../config.js';

let pushSubscription = null;

// Clave pÃºblica VAPID REAL de este proyecto (ver PUSH_REAL_SETUP.md para
// la clave privada, que NUNCA va en el frontend). Si necesitÃ¡s rotarla,
// generÃ¡ un par nuevo y actualizÃ¡ acÃ¡ + en los Secrets de la Edge Function.
const VAPID_PUBLIC_KEY = 'BKS5WiqA6iRzj52zakuKzGSbX6ZtZU8rXf12KrIDwGSMvgv5JElQcxNsgn2wwYUGEw6oQgv-sV8w4jYMmqzDCFc';

/**
 * Solicita permiso para mostrar notificaciones push.
 */
export async function requestPushPermission() {
  if (!('Notification' in window)) {
    showToast('Este navegador no soporta notificaciones');
    return false;
  }
  
  if (!('serviceWorker' in navigator)) {
    showToast('Service Worker no disponible');
    return false;
  }
  
  try {
    const permission = await Notification.requestPermission();
    
    if (permission === 'granted') {
      showToast('Notificaciones activadas âœ“', 'info');
      await subscribeToPush();
      return true;
    } else if (permission === 'denied') {
      showToast('Notificaciones bloqueadas. Revisa los permisos del navegador.');
      return false;
    } else {
      showToast('Notificaciones desactivadas');
      return false;
    }
  } catch (e) {
    console.error('Error al solicitar permisos de notificaciÃ³n:', e);
    showToast('Error al activar notificaciones');
    return false;
  }
}

/**
 * Suscribe al dispositivo a notificaciones push reales y guarda la
 * suscripciÃ³n en Supabase (tabla push_subscriptions) para que la Edge
 * Function send-push pueda encontrarla y mandarle avisos aunque esta
 * pestaÃ±a estÃ© cerrada.
 */
async function subscribeToPush() {
  try {
    const reg = await navigator.serviceWorker.ready;
    
    let subscription = await reg.pushManager.getSubscription();
    
    if (!subscription) {
      subscription = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
      });
    }
    
    pushSubscription = subscription;
    await guardarSuscripcionEnSupabase(subscription);
    
  } catch (e) {
    console.error('Error al suscribirse a push:', e);
    showToast('No se pudo activar el push: ' + (e.message || 'error desconocido'));
  }
}

/** Guarda (o actualiza) la suscripciÃ³n real en la base de datos. */
async function guardarSuscripcionEnSupabase(subscription) {
  if (!supabase || !state.session || !state.session.tenantId) return;
  const json = subscription.toJSON();
  const row = {
    tenant_id: state.session.tenantId,
    usuario_id: state.session.userId || null,
    endpoint: json.endpoint,
    p256dh: json.keys.p256dh,
    auth: json.keys.auth,
    user_agent: navigator.userAgent
  };
  const { error } = await supabase.from('push_subscriptions').upsert(row, { onConflict: 'endpoint' });
  if (error) {
    console.error('No se pudo guardar la suscripciÃ³n push en Supabase:', error);
    showToast('Se activÃ³ el permiso, pero no se pudo registrar en el servidor. Revisa tu conexiÃ³n.');
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

/**
 * EnvÃ­a una notificaciÃ³n LOCAL de prueba (usa el Service Worker igual que
 * las reales, para probar que el permiso y el icono funcionan). Las
 * notificaciones de verdad (pago pendiente, stock bajo, atraso) las manda
 * el servidor a travÃ©s de send-push, no esta funciÃ³n.
 */
export async function enviarNotificacionPush(titulo, mensaje, icono = './assets/icon-192.png') {
  if (!('Notification' in window)) {
    showToast('Este navegador no soporta notificaciones push');
    return;
  }
  if (Notification.permission !== 'granted') {
    console.warn('Notificaciones no permitidas');
    showToast('No tenÃ©s el permiso de notificaciones concedido en este navegador');
    return;
  }
  try {
    if (!('serviceWorker' in navigator)) throw new Error('Este navegador no soporta Service Worker');
    const reg = await navigator.serviceWorker.ready;
    await reg.showNotification(titulo, {
      body: mensaje,
      icon: icono,
      badge: icono,
      tag: 'ses-notif-' + Date.now(),
      requireInteraction: false,
      // Bug reportado: la notificaciÃ³n aparecÃ­a pero sin sonido. "silent"
      // sin especificar puede quedar en un estado ambiguo en algunos
      // navegadores/Android; se fuerza explÃ­citamente a false, y se agrega
      // "vibrate" porque en Android el sonido/vibraciÃ³n de una notificaciÃ³n
      // web depende de que el canal la reciba con estos datos.
      silent: false,
      vibrate: [200, 80, 200]
    });
    // AdemÃ¡s del sonido nativo del sistema (que depende del SO/navegador),
    // se suma el "ding" propio de la app mientras la pestaÃ±a estÃ¡ abierta,
    // para que la prueba se escuche siempre en este dispositivo.
    reproducirSonidoNotificacion();
  } catch (e) {
    console.error('Error al mostrar la notificaciÃ³n:', e);
    showToast('No se pudo mostrar la notificaciÃ³n: ' + (e.message || 'error desconocido') + '. RevisÃ¡ que las notificaciones del navegador/sistema operativo estÃ©n permitidas para este sitio.');
  }
}

/**
 * Renderiza el panel de control de notificaciones push en ConfiguraciÃ³n.
 */
export function renderPushPanel() {
  // iOS (Safari/Chrome) NO tiene la API de notificaciones disponible salvo
  // que el sitio estÃ© instalado como app desde la pantalla de inicio (iOS
  // 16.4+). Sin esta comprobaciÃ³n, "Notification.permission" explota con
  // un ReferenceError en esos casos y rompe toda la pestaÃ±a ConfiguraciÃ³n
  // â€” eso es lo que te estaba pasando en el celular.
  if (!('Notification' in window)) {
    const esIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
    return `
      <div class="panel">
        <div class="panel-title">Notificaciones Push</div>
        <div class="hint" style="margin-bottom:12px;">Alertas reales en el celular/PC (pagos pendientes, atrasos, stock bajo), aunque la app estÃ© cerrada.</div>
        <div class="hint" style="color:var(--red);">
          âš ï¸ Este navegador no soporta notificaciones push todavÃ­a.
          ${esIOS ? 'En iPhone: abrÃ­ el Ã­cono de Compartir â†’ "Agregar a pantalla de inicio", y despuÃ©s abrÃ­ el sistema desde ese Ã­cono (no desde Safari/Chrome directamente). Requiere iOS 16.4 o mÃ¡s nuevo.' : ''}
        </div>
      </div>
    `;
  }

  const permitido = Notification.permission === 'granted';
  const bloqueado = Notification.permission === 'denied';
  const suscrito = !!localStorage.getItem('ses-push-endpoint-ok');
  
  let html = `
    <div class="panel">
      <div class="panel-title">Notificaciones Push</div>
      <div class="hint" style="margin-bottom:12px;">Alertas reales en el celular/PC (pagos pendientes, atrasos, stock bajo), aunque la app estÃ© cerrada.</div>
  `;
  
  if (bloqueado) {
    html += `
      <div class="hint" style="color:var(--red);">
        âš ï¸ Las notificaciones estÃ¡n bloqueadas. Permite el acceso desde la configuraciÃ³n del navegador (Ã­cono de candado junto a la URL).
      </div>
    `;
  } else if (permitido) {
    html += `
      <div style="color:var(--green);margin-bottom:10px;">
        âœ“ Notificaciones activadas â€” este dispositivo estÃ¡ registrado para recibir avisos reales del servidor.
      </div>
      <button class="btn btn-ghost" onclick="testPushNotification()">Enviar notificaciÃ³n de prueba</button>
    `;
  } else {
    html += `
      <button class="btn btn-primary" onclick="activarNotificacionesPush()">Activar notificaciones</button>
    `;
  }
  
  html += `</div>`;
  return html;
}

/**
 * BotÃ³n para activar notificaciones (llamado desde HTML).
 */
export async function activarNotificacionesPush() {
  const ok = await requestPushPermission();
  if (ok) localStorage.setItem('ses-push-endpoint-ok', '1');
  if (ok && window.renderConfiguracion) window.renderConfiguracion();
}

/**
 * EnvÃ­a una notificaciÃ³n de prueba local (para confirmar permisos e Ã­cono).
 */
export function testPushNotification() {
  enviarNotificacionPush(
    'ðŸ”” SneakerMania',
    'Las notificaciones estÃ¡n funcionando correctamente en este dispositivo.'
  );
}

// Si el Service Worker avisa que la suscripciÃ³n cambiÃ³ (puede pasar sola,
// la maneja el navegador), la volvemos a guardar en Supabase.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'PUSH_SUBSCRIPTION_CHANGED') {
      subscribeToPush();
    }
  });
}

Object.assign(window, { 
  activarNotificacionesPush, 
  testPushNotification,
  renderPushPanel
});
