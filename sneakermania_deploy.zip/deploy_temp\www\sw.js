﻿/* Service Worker â€” SneakerMania (PWA / modo offline)
   Estrategia: stale-while-revalidate SOLO para archivos estÃ¡ticos del mismo
   origen. Las peticiones a Supabase (API, Auth, Storage) NUNCA se cachean. */
const CACHE = 'ses-static-v7';
const CORE = [
  './',
  './index.html',
  './manifest.json',
  './styles/main.css',
  './styles/fixes.css'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // Solo mismo origen: no tocar Supabase ni CDNs externas.
  if (url.origin !== self.location.origin) return;
  // No cachear llamadas a funciones/APIs.
  if (url.pathname.includes('/functions/') || url.pathname.includes('/rest/') || url.pathname.includes('/auth/')) return;

  e.respondWith(
    caches.open(CACHE).then(async (cache) => {
      const cached = await cache.match(req);
      const network = fetch(req).then((res) => {
        if (res && res.status === 200 && res.type === 'basic') cache.put(req, res.clone());
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});

/* ------------------------------------------------------------------
   PUSH REAL: recibe el mensaje que manda la Edge Function send-push
   (aunque la pestaÃ±a estÃ© cerrada o el celular bloqueado) y muestra
   la notificaciÃ³n nativa del sistema operativo.
   ------------------------------------------------------------------ */
self.addEventListener('push', (e) => {
  let data = {};
  try { data = e.data ? e.data.json() : {}; } catch (err) { data = { titulo: 'SneakerMania', mensaje: e.data ? e.data.text() : '' }; }
  const titulo = data.titulo || 'SneakerMania';
  const opciones = {
    body: data.mensaje || '',
    icon: data.icono || './assets/icon-192.png',
    badge: './assets/icon-192.png',
    tag: data.tag || ('ses-push-' + Date.now()),
    data: { url: data.url || './' },
    requireInteraction: false,
    // Bug reportado: llegaban notificaciones push reales sin sonido.
    // "silent" explÃ­cito en false y "vibrate" ayudan a que Android/el
    // navegador reproduzcan el sonido/vibraciÃ³n por defecto de la
    // notificaciÃ³n en vez de dejarla en un estado silencioso ambiguo.
    silent: false,
    vibrate: [200, 80, 200]
  };
  e.waitUntil(self.registration.showNotification(titulo, opciones));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || './';
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      const existing = clientsArr.find((c) => 'focus' in c);
      if (existing) return existing.focus();
      return self.clients.openWindow(url);
    })
  );
});

// Si el navegador renueva la suscripciÃ³n sola (puede pasar), avisamos a las
// pestaÃ±as abiertas para que la vuelvan a guardar en Supabase.
self.addEventListener('pushsubscriptionchange', (e) => {
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientsArr) => {
      clientsArr.forEach((c) => c.postMessage({ type: 'PUSH_SUBSCRIPTION_CHANGED' }));
    })
  );
});
