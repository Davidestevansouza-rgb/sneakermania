﻿/* ============================================================
   MÃ“DULO: PRECINTO NUMERADO (pares individuales de una orden)
   Cada par dentro de una orden tiene su propio cÃ³digo fÃ­sico
   (NRO_ORDEN-NRO_ITEM), tipo de servicio y responsable propios,
   estado de taller individual, y se marca como entregado uno por
   uno. Esta capa vive embebida en el Detalle de la orden (antes
   era un menÃº aparte "Precintos"; se fusionÃ³ dentro de Ã“rdenes
   porque Taller y Entrega ya son parte del ciclo de vida de una
   orden y duplicaban esa informaciÃ³n en dos lugares distintos).
   ============================================================ */
import { state, persist, todayISO, esEmpleado } from '../state.js';
import * as db from '../db.js';
import { showToast, ordenById, logActivity, closeModal, openModalEl, fmtDate } from '../ui.js';
import { escHtml, escAttr } from '../sanitize.js';
import { itemsDeOrden, estadoMostradoPar } from './ordenes.js';

// Estados posibles del campo it.estado ("artÃ­culos individuales"). Comparte
// SOLO EL VOCABULARIO (las mismas 7 etiquetas) con la orden completa
// (FLUJO_ESTADOS, en ordenes.js) y con el seguimiento en tiempo real
// (TIMELINE_STEPS), pero it.estado estÃ¡ vinculado y sincronizado
// EXCLUSIVAMENTE con Servicio de ProducciÃ³n â€” nunca con el seguimiento en
// tiempo real (ver cambiarEstadoItem mÃ¡s abajo y advanceItemTimelineStep
// en ordenes.js, que ya no lo toca). En la prÃ¡ctica, este campo solo
// llega a valer 'Control de calidad' o 'Biblioteca' si en algÃºn momento
// se guardaron asÃ­ desde fuera de este flujo (datos viejos); ProducciÃ³n
// nunca los escribe.
//
// El panel de "ArtÃ­culos individuales" (ver renderItemsPanelHTML) ya NO deja
// elegir el estado a mano con ningÃºn selector: es de solo lectura. it.estado
// avanza EXCLUSIVAMENTE cuando se registra en Servicio de ProducciÃ³n (ver
// registrarPares en produccion.js, que escribe it.estado vÃ­a
// SERVICIO_A_ESTADO_ITEM mÃ¡s abajo) â€” nunca desde el detalle de la orden.
//   - 'Recibido y registrado' es el estado inicial del artÃ­culo (se pone solo
//     al crearlo) hasta que ProducciÃ³n lo avance a 'Lavado'.
//   - 'Control de calidad' y 'Biblioteca' NO forman parte de este flujo:
//     esas etapas viven solo en el seguimiento en tiempo real del par
//     (timelineIndex) y en el estado de la ORDEN de servicio (ver
//     sincronizarEstadoOrdenDesdeTimelinePares en ordenes.js); se
//     muestran combinadas solo para lectura en pantalla vÃ­a
//     estadoMostradoPar(), sin escribir it.estado.
//   - 'Entregado' se maneja aparte con el checkbox de entrega, habilitado
//     reciÃ©n cuando el artÃ­culo ya estÃ¡ en 'Biblioteca' (Ãºltimo paso del
//     seguimiento, chequeado con estadoMostradoPar(), no con it.estado â€”
//     ver marcarItemEntregado).
// "ReparaciÃ³n" se quitÃ³ del flujo (ya no es un estado seleccionable);
// "Secado"+"Detallado" y "Pintado"+"PersonalizaciÃ³n" quedaron unificados
// en un solo paso cada uno; "Listo para retirar" se quitÃ³ (el flujo
// termina en "Biblioteca").
export const ITEM_ESTADOS = ['Recibido y registrado', 'Lavado', 'Secado y detallado', 'Pintado y personalizado', 'Control de calidad', 'Biblioteca', 'Entregado'];

// Orden de avance de cada estado (para saber cuÃ¡l es el "mÃ¡s atrasado"
// entre los pares de una orden). Como el par y la orden comparten
// vocabulario, ya no hace falta una tabla de conversiÃ³n aparte.
const RANGO_ITEM = { 'Recibido y registrado': 0, 'Lavado': 1, 'Secado y detallado': 2, 'Pintado y personalizado': 3, 'Control de calidad': 4, 'Biblioteca': 5 };

// Mapeo del "servicio" que se registra en ProducciÃ³n (Lavado/Secado y
// detallado/Pintado y personalizado, ver el <select> "Servicio" en la
// secciÃ³n ProducciÃ³n) al estado unificado del par que le corresponde.
// Ahora los 3 servicios usan exactamente el mismo texto que su estado
// (ver ITEM_ESTADOS), asÃ­ que el mapeo queda 1 a 1. "ReparaciÃ³n" se
// quitÃ³ como servicio elegible en ProducciÃ³n (ya no se registra);
// "Secado" y "Detallado" se unificaron en un solo servicio, igual que
// ya estaban unificados como un solo paso en ITEM_ESTADOS.
export const SERVICIO_A_ESTADO_ITEM = {
  'Lavado': 'Lavado',
  'Secado y detallado': 'Secado y detallado',
  'Pintado y personalizado': 'Pintado y personalizado'
};

/** Refresca el panel de pares embebido en el detalle de la orden, si
 *  estÃ¡ abierto, y la lista general de Ã³rdenes (por si cambiÃ³ el chip
 *  de estado de entrega). */
function refrescarVistas(ordenId) {
  const cont = document.getElementById('orden-detalle-items');
  if (cont) cont.innerHTML = renderItemsPanelHTML(ordenId);
  if (window.renderOrdenes) window.renderOrdenes();
}

/** HTML del panel de "ArtÃ­culos individuales (Taller y Entrega)" que se
 *  incrusta dentro del modal de Detalle de orden. Ya NO incluye acciones
 *  de entrega (ni el checkbox "Entregado" por artÃ­culo, ni el botÃ³n "Cerrar
 *  orden"): este panel es solo para el avance de trabajo del taller.
 *  El Estado de cada par es de SOLO LECTURA acÃ¡ (nunca se elige a mano
 *  en el detalle de la orden): avanza Ãºnicamente cuando se registra en
 *  Servicio de ProducciÃ³n. El chip de Pago y la pÃ­ldora de Prioridad que
 *  se muestran junto al Estado son datos de la ORDEN (o.estadoPago /
 *  o.prioridad), iguales para todos sus pares e independientes entre sÃ­:
 *  ni el Pago ni la Prioridad de la orden dependen del Estado o de la
 *  Prioridad/Pago de ningÃºn par en particular, y viceversa.
 */
export function renderItemsPanelHTML(ordenId) {
  const items = itemsDeOrden(ordenId);
  if (!items.length) return '<div class="hint">Esta orden no tiene artÃ­culos registrados.</div>';

  return (
    items.map(it => {
      const servicios = Array.isArray(it.tipoServicio) && it.tipoServicio.length ? it.tipoServicio.join(', ') : 'Sin servicio asignado';
      // Datos del anÃ¡lisis de IA guardados en este par (si ya se le
      // hizo un anÃ¡lisis). Se listan uno debajo del otro (no en fila)
      // para que se vea toda la informaciÃ³n sin tener que desplazar
      // la pantalla hacia un lado.
      const iaInfo = [
        ['Marca', it.marca], ['Modelo', it.modelo], ['Tipo', it.tipoCalzado],
        ['Color', it.color], ['Material', it.material],
        ['Estado del artÃ­culo', it.estadoCalzado], ['Tratamiento sugerido', it.tratamientoSugerido]
      ].filter(([, v]) => v);
      const iaHTML = iaInfo.length
        ? '<div style="margin-top:8px;padding-top:8px;border-top:1px dashed var(--line);display:flex;flex-direction:column;gap:2px;">' +
            '<div class="hint" style="font-weight:700;">ðŸ¤– AnÃ¡lisis de IA</div>' +
            iaInfo.map(([label, val]) => '<div class="hint"><strong>' + escHtml(label) + ':</strong> ' + escHtml(val) + '</div>').join('') +
          '</div>'
        : '';
      // Este panel muestra el estado REAL de it.estado, de solo lectura,
      // sin mezclarlo con el Seguimiento en tiempo real (timelineIndex).
      // Pares individuales queda vinculado y sincronizado EXCLUSIVAMENTE
      // con ProducciÃ³n: avanzar el timeline de este par (o de cualquier
      // otro), o elegir un estado a mano acÃ¡, ya no es posible â€” el Ãºnico
      // lugar que escribe it.estado es registrarPares() en produccion.js.
      // (Antes se usaba estadoMostradoPar(), que sÃ­ mezclaba ambos flujos
      // para mostrar en pantalla â€” eso quedÃ³ reservado para otras vistas de
      // solo lectura como chips/QR/filtros, nunca para este panel.)
      const estadoPar = it.estado;
      const orden = ordenById(it.ordenId);
      // Pago y Prioridad pertenecen al resumen de la orden y ya se muestran
      // fuera de este bloque. No se repiten dentro de cada par.
      const pagoHTML = '';
      const prioridadHTML = '';
      // El estado de trabajo del par ya NO se elige a mano acÃ¡: es de
      // solo lectura. Avanza Ãºnicamente cuando se registra en Servicio de
      // ProducciÃ³n (ver registrarPares en produccion.js y
      // SERVICIO_A_ESTADO_ITEM mÃ¡s arriba), que es quien escribe it.estado.
      const estadoHTML = '<span class="hint">Estado: ' + escHtml(estadoPar) +
        (estadoPar === 'Entregado' ? ' âœ“' : '') + '</span>';
      // Fechas propias del par, tal como se cargaron al crear la orden
      // (ver fechaIngresoPar / fechaEntregaPar en agregarFilaItemOrden,
      // ordenes.js). Si el par no tiene fecha propia guardada (datos
      // viejos), se cae a la fecha general de la orden como respaldo.
      const fechaIngresoHTML = it.fechaIngreso || orden.fechaIngreso;
      const fechaEntregaEstHTML = it.fechaEntregaEstimada || orden.fechaEstimada;
      const fechasParHTML = '<div class="hint">Ingreso: ' + fmtDate(fechaIngresoHTML) +
        ' Â· Entrega estimada: ' + fmtDate(fechaEntregaEstHTML) + '</div>';
      return '<div class="panel" style="margin-bottom:8px;padding:10px;">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">' +
          '<div>' +
            '<div><strong class="mono">' + escHtml(it.codigo) + '</strong>' + (it.descripcion ? ' Â· ' + escHtml(it.descripcion) : '') + '</div>' +
            '<div class="hint">' + escHtml(servicios) + ' Â· Responsable: ' + escHtml(it.responsable || 'Sin asignar') + '</div>' +
            fechasParHTML +
          '</div>' +
          '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">' +
            estadoHTML +
          '</div>' +
        '</div>' +
        iaHTML +
      '</div>';
    }).join('')
  );
}

export async function cambiarEstadoItem(itemId, nuevoEstado) {
  const item = (state.ordenItems || []).find(it => it.id === itemId);
  if (!item) return;
  item.estado = nuevoEstado;
  // it.estado queda vinculado y sincronizado SOLO con Servicio de
  // ProducciÃ³n: cambiar el estado de trabajo acÃ¡ (a mano, o desde
  // ProducciÃ³n â€” ver registrarPares en produccion.js) nunca toca el
  // Seguimiento en tiempo real del par (timelineIndex/timelineDates), ni
  // al revÃ©s (ver advanceItemTimelineStep en ordenes.js, que ya no
  // escribe it.estado). Son dos flujos completamente independientes.
  try {
    await persist();
    await db.saveOrdenItem(item);
    logActivity('ActualizÃ³ el artÃ­culo ' + item.codigo + ' a "' + nuevoEstado + '"');
    // Vincula con el estado de la orden: la orden se muestra en la
    // etapa mÃ¡s atrasada entre todos sus pares que aÃºn no fueron
    // entregados (asÃ­ el tablero general refleja el avance real del taller).
    await sincronizarEstadoOrdenDesdeItems(item.ordenId);
    showToast('ArtÃ­culo ' + item.codigo + ' â†’ ' + nuevoEstado);
    refrescarVistas(item.ordenId);
  } catch (e) {
    console.error('Error al actualizar el estado del artÃ­culo:', e);
    showToast('No se pudo actualizar el estado');
  }
}

/** Recalcula el estado de la orden a partir de it.estado de sus pares
 *  pendientes (no entregados): queda en la etapa mÃ¡s atrasada entre
 *  todos. Esta es la mitad "ProducciÃ³n" del vÃ­nculo ordenâ†”artÃ­culos â€” solo
 *  cubre Recibido/Lavado/Secado y detallado/Pintado y personalizado (ver
 *  RANGO_ITEM), porque it.estado nunca pasa de ahÃ­. La otra mitad
 *  (Control de calidad en adelante) la sincroniza por separado el
 *  Seguimiento en tiempo real â€” ver sincronizarEstadoOrdenDesdeTimelinePares
 *  en ordenes.js, que no usa it.estado para nada. */
export async function sincronizarEstadoOrdenDesdeItems(ordenId) {
  const o = ordenById(ordenId);
  if (!o) return;
  const items = itemsDeOrden(ordenId);
  const pendientes = items.filter(it => !it.entregado && RANGO_ITEM[it.estado] !== undefined);
  if (!pendientes.length) return; // sin pares en flujo de taller: no se toca el estado de la orden
  const masAtrasado = pendientes.reduce((min, it) => RANGO_ITEM[it.estado] < RANGO_ITEM[min.estado] ? it : min, pendientes[0]);
  if (masAtrasado.estado !== o.estado && o.estado !== 'Entregado') {
    o.estado = masAtrasado.estado;
    await db.saveOrden(o);
  }
}

export async function marcarItemEntregado(itemId, entregado) {
  const item = (state.ordenItems || []).find(it => it.id === itemId);
  if (!item) return;
  if (entregado) {
    const orden = ordenById(item.ordenId);
    // 1) El artÃ­culo debe haber llegado a "Biblioteca" (Ãºltimo paso del
    //    seguimiento en tiempo real) antes de poder entregarse. Esa etapa
    //    la alcanza el Seguimiento en tiempo real (nunca it.estado, que es
    //    de ProducciÃ³n), asÃ­ que se chequea con estadoMostradoPar(), que
    //    la refleja sin sincronizar nada.
    if (estadoMostradoPar(item) !== 'Biblioteca') {
      showToast('âš  El artÃ­culo ' + item.codigo + ' debe estar en estado "Biblioteca" antes de entregarse');
      refrescarVistas(item.ordenId); // revierte el checkbox visualmente
      return;
    }
    // 2) Se permite entregar pares sueltos aunque falte pagar (ej. el cliente
    //    viene a buscar un par antes de recoger el resto), PERO no se puede
    //    dejar TODOS los pares entregados (entregar el Ãºltimo pendiente) si la
    //    orden todavÃ­a tiene saldo pendiente / sin pagar.
    if (orden && orden.estadoPago !== 'Pagado') {
      const pendientesAntes = itemsDeOrden(orden.id).filter(it => !it.entregado);
      if (pendientesAntes.length <= 1) { // este serÃ­a el Ãºltimo par pendiente
        showToast('âš  No se puede entregar el Ãºltimo artÃ­culo: la orden #' + orden.numero + ' tiene saldo pendiente (' + (orden.estadoPago || 'pendiente') + '). Cobra el saldo antes de entregar todo.');
        refrescarVistas(orden.id); // revierte el checkbox visualmente
        return;
      }
    }
  }
  item.entregado = entregado;
  // it.estado es de ProducciÃ³n y nunca toma valores del Seguimiento en
  // tiempo real (Control de calidad/Biblioteca): al entregar se marca
  // 'Entregado'; al desmarcar, vuelve al Ãºltimo estado de ProducciÃ³n real
  // ('Pintado y personalizado', el tope de ese flujo), no a 'Biblioteca'
  // â€” eso sigue viviendo solo en el timelineIndex del par, sin tocar
  // este campo.
  item.estado = entregado ? 'Entregado' : (item.estado === 'Entregado' ? 'Pintado y personalizado' : item.estado);
  item.fechaEntrega = entregado ? todayISO(0) : null;
  try {
    await persist();
    await db.saveOrdenItem(item);
    logActivity((entregado ? 'EntregÃ³' : 'DesmarcÃ³ entrega de') + ' el artÃ­culo ' + item.codigo);
    refrescarVistas(item.ordenId);
  } catch (e) {
    console.error('Error al marcar la entrega del artÃ­culo:', e);
    showToast('No se pudo actualizar la entrega');
  }
}

/** Intenta cerrar la orden como entregada. Avisa si falta algÃºn par. */
export async function cerrarOrdenEntrega(ordenId) {
  const o = ordenById(ordenId);
  if (!o) return;
  const items = itemsDeOrden(ordenId);
  const pendientes = items.filter(it => !it.entregado);
  if (pendientes.length > 0) {
    showToast('âš  Faltan ' + pendientes.length + ' ' + (pendientes.length === 1 ? 'artÃ­culo' : 'artÃ­culos') + ' por entregar: ' + pendientes.map(p => p.codigo).join(', '));
    return;
  }
  // No se puede cerrar la orden completa si todavÃ­a tiene saldo pendiente.
  if (o.estadoPago !== 'Pagado') {
    showToast('âš  No se puede cerrar la orden #' + o.numero + ': tiene saldo pendiente (' + (o.estadoPago || 'pendiente') + '). Cobra el saldo antes de entregar todo.');
    return;
  }
  if (o.estado !== 'Entregado') {
    o.estado = 'Entregado';
    o.fechaEntrega = o.fechaEntrega || new Date().toISOString().slice(0, 10);
    try {
      await persist();
      await db.saveOrden(o);
      logActivity('CerrÃ³ la orden #' + o.numero + ' â€” todos los artÃ­culos entregados');
    } catch (e) { console.error(e); }
  }
  showToast('Orden #' + o.numero + ' entregada completa âœ“');
  refrescarVistas(ordenId);
}

/** HTML del panel de entrega por artÃ­culo, dentro de la "ventanilla" de
 *  entrega (modal-entrega-pares). Por cada par muestra su cÃ³digo, su
 *  estado mostrado (ProducciÃ³n combinado con Seguimiento en tiempo
 *  real, solo para lectura) y una acciÃ³n: si ya estÃ¡ entregado, una
 *  etiqueta fija; si no, un botÃ³n "Entregar" habilitado solo cuando el
 *  artÃ­culo llegÃ³ a "Biblioteca" (ver marcarItemEntregado, que valida esto
 *  y el saldo pendiente antes de guardar nada). */
function renderEntregaParesHTML(ordenId) {
  const o = ordenById(ordenId);
  if (!o) return '<div class="hint">No se encontrÃ³ la orden.</div>';
  const items = itemsDeOrden(ordenId);
  if (!items.length) {
    // Orden sin pares registrados: se entrega de una sola vez (no hay
    // nada para desglosar acÃ¡). Se avisa y se deja la acciÃ³n de cierre
    // directo, igual que antes de existir este desglose por par.
    return '<div class="hint">Esta orden no tiene artÃ­culos registrados individualmente.</div>' +
      (o.estado !== 'Entregado'
        ? '<div style="margin-top:12px;"><button class="btn btn-teal btn-sm" onclick="cerrarOrdenSinPares(\'' + escAttr(o.id) + '\')">ðŸ“¦ Marcar orden como Entregada</button></div>'
        : '<div class="hint" style="margin-top:12px;">Esta orden ya estÃ¡ Entregada âœ“</div>');
  }
  const pendientes = items.filter(it => !it.entregado).length;
  const resumen = '<div class="hint" style="margin-bottom:10px;">' +
    (pendientes === 0
      ? 'Todos los artÃ­culos de la orden #' + escHtml(o.numero) + ' ya fueron entregados.'
      : pendientes + ' de ' + items.length + ' ' + (items.length === 1 ? 'artÃ­culo pendiente' : 'artÃ­culos pendientes') + ' de entrega en la orden #' + escHtml(o.numero) + '.') +
    '</div>';
  return resumen + items.map(it => {
    const estadoMostrado = estadoMostradoPar(it);
    const listoParaEntregar = estadoMostrado === 'Biblioteca';
    let accion;
    if (it.entregado) {
      accion = '<span class="hint">Entregado' + (it.fechaEntrega ? ' Â· ' + fmtDate(it.fechaEntrega) : '') + ' âœ“</span>';
    } else if (listoParaEntregar) {
      accion = '<button class="btn btn-teal btn-sm" onclick="entregarParDesdeModal(\'' + escAttr(it.id) + '\')">Entregar</button>';
    } else {
      accion = '<span class="hint" title="Debe llegar a &quot;Biblioteca&quot; en el seguimiento en tiempo real antes de poder entregarse">AÃºn no listo (' + escHtml(estadoMostrado) + ')</span>';
    }
    return '<div class="panel" style="margin-bottom:8px;padding:10px;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">' +
      '<div>' +
        '<div><strong class="mono">' + escHtml(it.codigo) + '</strong>' + (it.descripcion ? ' Â· ' + escHtml(it.descripcion) : '') + '</div>' +
        '<div class="hint">' + escHtml(estadoMostrado) + '</div>' +
      '</div>' +
      accion +
    '</div>';
  }).join('');
}

/** Abre la "ventanilla" de entrega: un modal aparte (no el Detalle de
 *  orden) donde se listan los pares de la orden con su propio botÃ³n
 *  "Entregar", para el caso en que el cliente venga a buscar solo
 *  alguno de los pares antes que el resto. Reemplaza, en el botÃ³n
 *  "ðŸ“¦ Entregado" de la tarjeta de la orden, el cierre directo de toda
 *  la orden de una sola vez (ver entregarOrden en ordenes.js, que ya no
 *  se usa desde ese botÃ³n). */
export function openEntregaParesModal(ordenId) {
  if (esEmpleado()) { showToast('No tienes permiso para marcar la entrega'); return; }
  const o = ordenById(ordenId);
  if (!o) return;
  const extra = document.getElementById('entrega-pares-titulo-extra');
  if (extra) extra.textContent = '#' + o.numero;
  const cont = document.getElementById('entrega-pares-content');
  if (cont) cont.innerHTML = renderEntregaParesHTML(ordenId);
  openModalEl('modal-entrega-pares');
}

/** Refresca el contenido de la ventanilla de entrega, si estÃ¡ abierta,
 *  ademÃ¡s del resto de vistas (panel de pares del detalle, lista de
 *  Ã³rdenes). */
function refrescarVentanillaEntrega(ordenId) {
  const modalAbierto = document.getElementById('modal-entrega-pares');
  if (modalAbierto && modalAbierto.classList.contains('open')) {
    const cont = document.getElementById('entrega-pares-content');
    if (cont) cont.innerHTML = renderEntregaParesHTML(ordenId);
  }
}

/** Wrapper que llama el botÃ³n "Entregar" de cada artÃ­culo en la ventanilla:
 *  usa la misma lÃ³gica ya validada de marcarItemEntregado (chequea que
 *  el artÃ­culo estÃ© en "Biblioteca" y el saldo pendiente) y despuÃ©s refresca
 *  tambiÃ©n la ventanilla, no solo el panel del Detalle de orden. */
export async function entregarParDesdeModal(itemId) {
  const item = (state.ordenItems || []).find(it => it.id === itemId);
  if (!item) return;
  await marcarItemEntregado(itemId, true);
  refrescarVentanillaEntrega(item.ordenId);
}

/** Cierra directo una orden que nunca tuvo pares individuales
 *  registrados (no hay nada para desglosar en la ventanilla). Misma
 *  validaciÃ³n de saldo pendiente que ya tenÃ­a entregarOrden. */
export async function cerrarOrdenSinPares(ordenId) {
  if (esEmpleado()) { showToast('No tienes permiso para marcar la entrega'); return; }
  const o = ordenById(ordenId);
  if (!o) return;
  if (o.estado === 'Entregado') { showToast('La orden #' + o.numero + ' ya estÃ¡ entregada'); return; }
  if ((o.estadoPago || 'Pendiente') !== 'Pagado') {
    showToast('âš  No se puede marcar como Entregado la orden #' + o.numero + ': tiene saldo pendiente (' + (o.estadoPago || 'pendiente') + '). Cobra el saldo antes de marcarla.');
    return;
  }
  try {
    o.estado = 'Entregado';
    o.fechaEntrega = o.fechaEntrega || todayISO(0);
    await persist();
    await db.saveOrden(o);
    logActivity('MarcÃ³ como Entregado la orden #' + o.numero);
    if (window.renderOrdenes) window.renderOrdenes();
    showToast('Orden #' + o.numero + ' â†’ Entregado âœ“');
    closeModal('modal-entrega-pares');
  } catch (e) { console.error(e); showToast('Error al marcar la entrega'); }
}

Object.assign(window, {
  renderItemsPanelHTML, cambiarEstadoItem, marcarItemEntregado, cerrarOrdenEntrega,
  openEntregaParesModal, entregarParDesdeModal, cerrarOrdenSinPares
});
