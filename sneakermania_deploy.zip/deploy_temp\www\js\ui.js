﻿/* ============================================================
   HELPERS DE INTERFAZ â€” SneakerMania
   ============================================================
   Funciones utilitarias compartidas: toasts, formateo, bÃºsquedas
   en memoria, chips de estado, apertura/cierre de modales,
   registro de actividad y el indicador de conexiÃ³n.
   ============================================================ */
import { state, todayISO } from './state.js';
import { LOCALE, CURRENCY_SYMBOL } from './config.js';
import { escHtml } from './sanitize.js';

/* ---------- Toast ---------- */
export function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------- Sonido de alerta (notificaciones) ----------
   Bug reportado: las notificaciones (campanita / push de prueba) aparecÃ­an
   en pantalla pero sin ningÃºn sonido. No dependemos de un archivo de audio
   externo (que podÃ­a faltar o no cargar): se genera un "ding" corto con
   Web Audio API. Los navegadores exigen un gesto del usuario antes de
   dejar sonar audio, asÃ­ que el AudioContext se crea reciÃ©n al primer
   click/tap en la pÃ¡gina (ver bindPrimerGestoAudio, llamado desde
   app.js al iniciar) y se reutiliza despuÃ©s para sonar aunque la
   notificaciÃ³n llegue sola (ej. el sync automÃ¡tico cada 60s). */
let audioCtx = null;
let audioDesbloqueado = false;

export function bindPrimerGestoAudio() {
  if (audioDesbloqueado) return;
  const desbloquear = () => {
    audioDesbloqueado = true;
    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
    } catch (e) { /* navegador sin soporte de Web Audio: se ignora, no rompe la app */ }
    document.removeEventListener('click', desbloquear);
    document.removeEventListener('touchstart', desbloquear);
  };
  document.addEventListener('click', desbloquear, { once: true });
  document.addEventListener('touchstart', desbloquear, { once: true });
}

/** Reproduce un "ding" corto de dos tonos para alertar de una notificaciÃ³n nueva. */
export function reproducirSonidoNotificacion() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const ahora = audioCtx.currentTime;
    [[880, ahora], [1175, ahora + 0.12]].forEach(([freq, inicio]) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, inicio);
      gain.gain.exponentialRampToValueAtTime(0.22, inicio + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, inicio + 0.22);
      osc.connect(gain).connect(audioCtx.destination);
      osc.start(inicio);
      osc.stop(inicio + 0.24);
    });
  } catch (e) {
    // Si el navegador bloquea el audio (sin gesto previo, polÃ­tica del SO, etc.)
    // no debe romper el flujo de notificaciones: solo se pierde el sonido.
    console.warn('No se pudo reproducir el sonido de notificaciÃ³n:', e);
  }
}

/* ---------- Bloqueo de botÃ³n (anti-doble-guardado) ----------
   Deshabilita el botÃ³n que dispara una acciÃ³n de guardado y muestra
   "Guardando..." mientras se completa. Devuelve una funciÃ³n que
   restaura el botÃ³n a su estado original (llamar en finally). */
export function lockBtn(btn, texto = 'Guardandoâ€¦') {
  if (!btn || btn.disabled) return () => {};
  const prevHtml = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = texto;
  return () => { btn.disabled = false; btn.innerHTML = prevHtml; };
}

/* ---------- Formateo ---------- */
export function fmtMoney(n) {
  return CURRENCY_SYMBOL + (Number(n) || 0)
    .toLocaleString(LOCALE, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
export function fmtDate(d) {
  if (!d) return 'â€”';
  // Acepta tanto fechas simples (YYYY-MM-DD) como timestamps ISO.
  // Antes se agregaba 'T00:00:00' siempre, lo que producÃ­a 'Invalid Date'
  // cuando el valor ya era un timestamp como 2026-08-25T14:30:00.000Z.
  const raw = String(d).trim();
  const dt = /^\d{4}-\d{2}-\d{2}$/.test(raw)
    ? new Date(raw + 'T00:00:00')
    : new Date(raw);
  if (Number.isNaN(dt.getTime())) return 'â€”';
  return dt.toLocaleDateString(LOCALE, { day: '2-digit', month: 'short', year: 'numeric' });
}
export function fmtServicios(ts) {
  if (Array.isArray(ts)) return ts.join(', ') || 'â€”';
  return ts || 'â€”';
}

/* ---------- BÃºsquedas en memoria ---------- */
export function clienteNombre(id) {
  const c = state.clientes.find(x => x.id === id);
  return c ? c.nombre : 'â€”';
}
export function clienteById(id) { return state.clientes.find(x => x.id === id); }
export function ordenById(id) { return state.ordenes.find(x => x.id === id); }

/* ---------- Chips de estado (texto escapado por seguridad) ---------- */
// Convierte el texto del estado en un slug de clase CSS vÃ¡lido: sin
// tildes, sin espacios (los estados unificados tienen varias palabras,
// ej. "Secado y detallado"), todo en minÃºscula y separado por guiones.
function slugEstado(e) {
  return String(e)
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // quita tildes
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}
export function chipEstado(e) {
  return '<span class="chip chip-' + slugEstado(e) + '">' + escHtml(e) + '</span>';
}
export function chipPago(e) {
  return '<span class="chip chip-' + slugEstado(e) + '">' + escHtml(e) + '</span>';
}
export function priPill(p) {
  return '<span class="pill-priority pri-' + escHtml(String(p).toLowerCase()) + '">' + escHtml(p) + '</span>';
}

/* ---------- Modales ----------
   Bug reportado: al abrir un modal, el fondo (la pantalla detrÃ¡s) se
   desplazaba/saltaba â€” tÃ­pico de no bloquear el scroll del body mientras
   hay un modal abierto: si el contenido de fondo tenÃ­a scrollbar y el
   modal se abre con position:fixed pero el body sigue scrolleable, el
   navegador puede saltar o la barra de scroll aparecer/desaparecer y
   correr todo el layout unos pÃ­xeles. Se bloquea el scroll del body
   mientras algÃºn modal estÃ¡ abierto y se compensa el ancho de la
   scrollbar (con un padding-right igual a ese ancho) para que el
   contenido de fondo no "salte" horizontalmente al desaparecer la barra.
   Como puede haber mÃ¡s de un modal abierto/cerrÃ¡ndose en secuencia, se
   lleva un contador en vez de bloquear/desbloquear a ciegas. */
let modalesAbiertos = 0;
function bloquearScrollBody() {
  if (modalesAbiertos === 0) {
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    document.body.style.paddingRight = scrollbarWidth > 0 ? scrollbarWidth + 'px' : '';
    document.body.classList.add('modal-open-lock');
  }
  modalesAbiertos++;
}
function desbloquearScrollBody() {
  modalesAbiertos = Math.max(0, modalesAbiertos - 1);
  if (modalesAbiertos === 0) {
    document.body.classList.remove('modal-open-lock');
    document.body.style.paddingRight = '';
  }
}
export function closeModal(id) {
  const el = document.getElementById(id);
  if (!el) return;
  if (el.classList.contains('open')) desbloquearScrollBody();
  el.classList.remove('open');
}
export function openModalEl(id) {
  const el = document.getElementById(id);
  if (!el) return;
  if (!el.classList.contains('open')) bloquearScrollBody();
  el.classList.add('open');
}

/* Exponer helpers de modal en window para los onclick inline del HTML
   (los botones X y Cancelar usan onclick="closeModal('...')"). */
if (typeof window !== 'undefined') {
  window.closeModal = closeModal;
  window.openModalEl = openModalEl;
}

/* ---------- Registro de actividad ----------
   Actualiza el log en memoria y lo empuja a Supabase (actividad_log)
   sin bloquear la interfaz. La importaciÃ³n de db.js es dinÃ¡mica para
   evitar dependencias circulares. */
export function logActivity(accion) {
  if (!state.activityLog) state.activityLog = [];
  state.activityLog.unshift({
    fecha: new Date().toISOString(),
    usuario: state.session ? state.session.user : 'sistema',
    accion
  });
  state.activityLog = state.activityLog.slice(0, 60);
  // Empuje remoto (best-effort).
  import('./db.js')
    .then(db => db.logRemote(accion))
    .catch(() => { /* si falla, queda solo en el log local/cachÃ© */ });
}

/* ---------- Indicador de conexiÃ³n ----------
   Refleja el estado online/offline/sincronizando en la barra superior. */
export function setConnStatus(mode, pending = 0) {
  const el = document.getElementById('conn-status');
  if (!el) return;
  el.classList.remove('online', 'offline', 'syncing');
  if (mode === 'offline') {
    el.classList.add('offline');
    el.textContent = 'Sin conexiÃ³n' + (pending ? ' Â· ' + pending + ' por sincronizar' : '');
    el.style.display = 'inline-flex';
  } else if (mode === 'syncing') {
    el.classList.add('syncing');
    el.textContent = 'Sincronizandoâ€¦';
    el.style.display = 'inline-flex';
  } else {
    el.classList.add('online');
    el.textContent = 'En lÃ­nea';
    // En lÃ­nea y sin pendientes: se oculta tras un momento.
    el.style.display = pending ? 'inline-flex' : 'none';
  }
}

// Se re-exporta todayISO por conveniencia para los mÃ³dulos de features.
export { todayISO };
